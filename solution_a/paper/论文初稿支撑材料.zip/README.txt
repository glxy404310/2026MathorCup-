啤酒风味建模论文初稿电子附录

本包与论文初稿配套，表D-1的所有路径均相对于本包根目录。

1. solution_a/src/ 保存全部实验源程序；solution_a/run_all.py 为统一复现入口。
2. solution_a/requirements-lock.txt 固定本次计算依赖，建议Python 3.13独立环境。
3. paper_results/ 保存本次论文引用及历轮比较的CSV和JSON；它是结果备份，不是运行目录。
4. solution_a/paper/ 保存正文结构化源稿、图表脚本、原生公式构建、文献及逐行化学证据。
   chemical_evidence_final.csv的source_ref及chemical_references_final.json采用论文最终参考编号。
5. 原始赛题附件不在本包内。复现时将原题文件夹与solution_a并列，保持原始目录及文件名。
   在新目录中安装依赖后运行 python solution_a/run_all.py，将重建solution_a/outputs/。
   不要把paper_results复制为outputs后直接运行，以免不完整的模型工件触发冻结校验。
6. 模型工件可由源程序重新训练。此包不包含较大的joblib权重及候选逐项压缩缓存；
   完整候选搜索和核验由源程序重建，逐源选谱、72策略点及十情景检查已保存。
7. 论文再生另需python-docx和lxml，并需保留赛题论文模板；图表需可用中文字体。

初稿的实质边界：未恢复原始0—6评分；部分化学关联没有匹配的直接机制依据；
Stale hops与迁移通过仅为模型检查，尚无迁移后实际品评或生产验证。
