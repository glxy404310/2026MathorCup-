A题论文配套程序与数值结果

1. PDF附录E已印出全部源程序；本包保留可直接运行的文件及缩进。
2. solution_a/src/为模型程序，run_all.py为统一入口，paper/为论文结构化源稿、表图、构建及检查程序。
3. paper_results/保存论文引用结果，不能替代完整outputs/。本包不含原始赛题附件、模型权重及大型候选缓存。
4. 原始赛题目录与solution_a并列，保持官方目录名。计算使用Python 3.13及requirements-lock.txt。
   Windows PowerShell在解压根目录运行：
   py -3.13 -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r solution_a/requirements-lock.txt
   .\.venv\Scripts\python.exe -X utf8 solution_a/run_all.py --rebuild
   全部模型、候选缓存与outputs由源码重建。--rebuild拒绝覆盖非空输出目录。
5. 对重建完成的完整目录，去掉--rebuild即可只读验证。报告写入solution_a/review/verification/。
6. 重建论文需原赛题Word模板、Windows中文字体和Word兼容COM接口（本次使用WPS）：
   python -m pip install -r solution_a/paper/requirements-paper.txt
   python solution_a/paper/make_figures.py
   python solution_a/paper/build_paper.py
   powershell -ExecutionPolicy Bypass -File solution_a/paper/export_pdf.ps1
   python solution_a/paper/source_appendix.py
   python solution_a/paper/package_support.py
   paper脚本读取outputs；欲保留论文原始数值，可在单独的论文构建副本中将paper_results复制为solution_a/outputs，
   仅运行上述paper构建脚本，不对该不完整副本运行run_all.py。
   verify_paper.py须在完整重建目录运行，并先用Poppler的pdftoppm命令把qa/main.pdf渲染为qa/render/page-*.png。
7. MANIFEST.json记录包内文件SHA-256。verification内为原始冻结结果的只读验证和独立重建检查记录。
8. 原评分量尺不能从现有附件唯一恢复，文中标准化预测不冒充0—6评分；化学相关不等于感官因果，迁移结果尚未经实际品评。
